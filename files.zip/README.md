# Yungg Star Graphics — Portfolio Website

Professional graphic design portfolio for **Emmanuel Nii Okwei Noi** (Yungg Star Graphics), based in Accra, Ghana.

## Files
- `index.html` — Full website (single page, all assets embedded)
- `vercel.json` — Vercel deployment config

## Deploy to Vercel
1. Upload both files to GitHub repo
2. Import repo on vercel.com
3. Click Deploy — done!

## Contact
- WhatsApp: +233 533 057 655
- Email: emmanuelnoi41@gmail.com
- Instagram: @iamyunggstar_
- Facebook: IamyunggStar
